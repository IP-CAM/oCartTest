<?php
$_['heading_title'] = 'MultiMerch Skeleton';
?>
