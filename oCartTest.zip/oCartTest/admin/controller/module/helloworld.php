<?php

class ControllerModuleHelloworld extends Controller {

private $error = array();

public function index(){
	
	$this->language->load('module/helloworld');
	
	$this->document->setTitle('heading_title');
	
	$this->load->model('setting/setting');
	
	    if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) { // Start If: Validates and check if data is coming by save (POST) method
        $this->model_setting_setting->editSetting('helloworld', $this->request->post);      // Parse all the coming data to Setting Model to save it in database.
 
        $this->session->data['success'] = $this->language->get('text_success'); // To display the success text on data save
 
        $this->redirect($this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL')); // Redirect to the Module Listing
    } // End If


	 /*Assign the language data for parsing it to view*/
    $this->data['heading_title'] = $this->language->get('heading_title');
    
    
 
	
}
	
	
}

?>
