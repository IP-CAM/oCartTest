<?php
class ControllerModuleMultimerchSkeleton extends Controller {
public function install() {
$this->load->model("module/multimerch_skeleton");
$this->model_module_multimerch_skeleton->createSchema();
}
public function uninstall() {
$this->load->model("module/multimerch_skeleton");
$this->model_module_multimerch_skeleton->deleteSchema();
}
}
?>
